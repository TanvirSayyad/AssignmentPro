/**
 * 
 */
/**
 * @author admin
 *
 */
module AssignmentProject {
}