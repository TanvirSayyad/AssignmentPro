package p1;
	import java.io.*;
	import java.util.*;

	public class BookIndexer {
	    public static void main(String[] args) {
	        String[] pageFiles = {"Page1.txt", "Page2.txt", "Page3.txt"};
	        String excludeWordsFile = "exclude-words.txt";
	        String indexFile = "index.txt";
	        
	        BookIndexer bookIndexer = new BookIndexer();
	        try {
	            List<String> excludeWords = bookIndexer.readExcludeWords(excludeWordsFile);
	            Map<String, Set<Integer>> index = bookIndexer.createIndex(pageFiles, excludeWords);
	            bookIndexer.writeIndexToFile(index, indexFile);
	            System.out.println("Index created successfully!");
	        } catch (IOException e) {
	            System.out.println("An error occurred: " + e.getMessage());
	        }
	    }
	    
	    private List<String> readExcludeWords(String excludeWordsFile) throws IOException {
	        List<String> excludeWords = new ArrayList<>();
	        BufferedReader reader = new BufferedReader(new FileReader(excludeWordsFile));
	        String line;
	        while ((line = reader.readLine()) != null) {
	            excludeWords.add(line.trim().toLowerCase());
	        }
	        reader.close();
	        return excludeWords;
	    }
	    
	    private Map<String, Set<Integer>> createIndex(String[] pageFiles, List<String> excludeWords) throws IOException {
	        Map<String, Set<Integer>> index = new TreeMap<>();
	        for (int i = 0; i < pageFiles.length; i++) {
	            BufferedReader reader = new BufferedReader(new FileReader(pageFiles[i]));
	            String line;
	            while ((line = reader.readLine()) != null) {
	                String[] words = line.split("\\s+|\\p{Punct}");
	                for (String word : words) {
	                    word = word.toLowerCase();
	                    if (!excludeWords.contains(word) && !word.isEmpty()) {
	                        Set<Integer> pages = index.getOrDefault(word, new HashSet<>());
	                        pages.add(i + 1);
	                        index.put(word, pages);
	                    }
	                }
	            }
	            reader.close();
	        }
	        return index;
	    }
	    
	    private void writeIndexToFile(Map<String, Set<Integer>> index, String indexFile) throws IOException {
	        BufferedWriter writer = new BufferedWriter(new FileWriter(indexFile));
	        for (Map.Entry<String, Set<Integer>> entry : index.entrySet()) {
	            writer.write(entry.getKey() + " : ");
	            Set<Integer> pages = entry.getValue();
	            Iterator<Integer> iterator = pages.iterator();
	            while (iterator.hasNext()) {
	                writer.write(iterator.next().toString());
	                if (iterator.hasNext()) {
	                    writer.write(",");
	                }
	            }
	            writer.newLine();
	        }
	        writer.close();
	    }
	}


